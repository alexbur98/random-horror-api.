const TMDB_BASE = "https://api.themoviedb.org/3";
const IMAGE_BASE = "https://image.tmdb.org/t/p";

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);

    try {
      if (request.method === "OPTIONS") return corsResponse(null);

      if (url.pathname === "/health") {
        return json({ ok: true, source: "tmdb-proxy" });
      }

      if (url.pathname === "/random") {
        return await randomMovie(env, ctx);
      }

      if (url.pathname === "/search") {
        const q = url.searchParams.get("q") || "";
        return await searchMovie(q, env, ctx);
      }

      if (url.pathname.startsWith("/movie/")) {
        const id = url.pathname.split("/").filter(Boolean)[1];
        return await movieDetails(id, env, ctx);
      }

      return json({ error: "Not found" }, 404);
    } catch (error) {
      return json({ error: String(error?.message || error) }, 500);
    }
  }
};

async function randomMovie(env, ctx) {
  const page = Math.floor(Math.random() * 25) + 1;

  const data = await tmdb("/discover/movie", env, {
    language: "ru-RU",
    sort_by: "popularity.desc",
    include_adult: "false",
    include_video: "false",
    with_genres: "27",
    "vote_count.gte": "80",
    "vote_average.gte": "6",
    "primary_release_date.gte": "2000-01-01",
    page: String(page)
  }, ctx);

  const results = (data.results || []).filter(movie => {
    return movie.poster_path && movie.overview && movie.genre_ids?.includes(27);
  });

  if (!results.length) return json({ error: "No horror movies found" }, 404);

  const picked = results[Math.floor(Math.random() * results.length)];
  return await movieDetails(picked.id, env, ctx);
}

async function searchMovie(query, env, ctx) {
  if (!query.trim()) return json({ error: "Empty query" }, 400);

  const data = await tmdb("/search/movie", env, {
    language: "ru-RU",
    include_adult: "false",
    query
  }, ctx);

  const results = (data.results || [])
    .filter(movie => movie.genre_ids?.includes(27))
    .map(normalizeMovieShort);

  return json({ results });
}

async function movieDetails(id, env, ctx) {
  const data = await tmdb(`/movie/${id}`, env, {
    language: "ru-RU",
    append_to_response: "images,videos"
  }, ctx);

  const trailer = pickTrailer(data.videos?.results || []);
  const gallery = (data.images?.backdrops || [])
    .slice(0, 12)
    .map(img => `${IMAGE_BASE}/w780${img.file_path}`);

  const logo = (data.images?.logos || []).find(l => l.iso_639_1 === "ru")
    || (data.images?.logos || []).find(l => l.iso_639_1 === "en")
    || (data.images?.logos || [])[0];

  return json({
    id: data.id,
    title: data.title,
    originalTitle: data.original_title,
    year: data.release_date ? data.release_date.slice(0, 4) : "—",
    overview: data.overview || "",
    runtime: data.runtime || null,
    rating: data.vote_average || null,
    voteCount: data.vote_count || null,
    genres: (data.genres || []).map(g => g.name),
    posterUrl: data.poster_path ? `${IMAGE_BASE}/w780${data.poster_path}` : null,
    backdropUrl: data.backdrop_path ? `${IMAGE_BASE}/w1280${data.backdrop_path}` : null,
    logoUrl: logo?.file_path ? `${IMAGE_BASE}/w500${logo.file_path}` : null,
    gallery,
    trailerUrl: trailer
  });
}

async function tmdb(path, env, query = {}, ctx) {
  if (!env.TMDB_TOKEN) {
    throw new Error("TMDB_TOKEN is missing in Cloudflare Worker secrets");
  }

  const cacheUrl = new URL(`https://cache.local${path}`);
  Object.entries(query).forEach(([key, value]) => {
    cacheUrl.searchParams.set(key, value);
  });

  const cacheKey = new Request(cacheUrl.toString(), { method: "GET" });
  const cache = caches.default;

  const cached = await cache.match(cacheKey);
  if (cached) return await cached.json();

  const url = new URL(`${TMDB_BASE}${path}`);
  Object.entries(query).forEach(([key, value]) => {
    url.searchParams.set(key, value);
  });

  const response = await fetch(url.toString(), {
    headers: {
      Authorization: `Bearer ${env.TMDB_TOKEN}`,
      accept: "application/json"
    }
  });

  if (!response.ok) throw new Error(`TMDb error ${response.status}`);

  const data = await response.json();

  const cachedResponse = new Response(JSON.stringify(data), {
    headers: {
      "content-type": "application/json",
      "cache-control": "public, max-age=21600"
    }
  });

  ctx.waitUntil(cache.put(cacheKey, cachedResponse.clone()));
  return data;
}

function normalizeMovieShort(movie) {
  return {
    id: movie.id,
    title: movie.title,
    originalTitle: movie.original_title,
    year: movie.release_date ? movie.release_date.slice(0, 4) : "—",
    overview: movie.overview || "",
    rating: movie.vote_average || null,
    posterUrl: movie.poster_path ? `${IMAGE_BASE}/w500${movie.poster_path}` : null,
    backdropUrl: movie.backdrop_path ? `${IMAGE_BASE}/w1280${movie.backdrop_path}` : null
  };
}

function pickTrailer(videos) {
  const trailer = videos.find(v =>
    v.site === "YouTube" && v.type === "Trailer" && v.iso_639_1 === "ru"
  ) || videos.find(v =>
    v.site === "YouTube" && v.type === "Trailer"
  ) || videos.find(v =>
    v.site === "YouTube"
  );

  return trailer ? `https://www.youtube.com/watch?v=${trailer.key}` : null;
}

function json(data, status = 200) {
  return corsResponse(JSON.stringify(data), status, {
    "content-type": "application/json; charset=utf-8"
  });
}

function corsResponse(body, status = 200, headers = {}) {
  return new Response(body, {
    status,
    headers: {
      ...headers,
      "access-control-allow-origin": "*",
      "access-control-allow-methods": "GET, OPTIONS",
      "access-control-allow-headers": "content-type, authorization"
    }
  });
}
