# Random Horror API — TMDb Proxy

Cloudflare Worker для Random Horror.

## Файлы

- `src/worker.js` — основной код Worker.
- `package.json` — команды для деплоя.
- `wrangler.toml` — настройки Cloudflare Worker.

## Важно

В Cloudflare нужно добавить secret:

```text
TMDB_TOKEN=твой TMDb Read Access Token
```

Это должен быть Read Access Token, который начинается с `eyJ...`.

## Проверка

После деплоя:

```text
/health
/random
/search?q=sinister
```
